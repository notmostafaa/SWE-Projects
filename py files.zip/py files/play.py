import tkinter
from tkinter import *
from tkinter import ttk
from database import Database
from tkinter import messagebox
import sqlite3

sign_in = Tk()

db = sqlite3.connect('data.db')
cr = db.cursor()


#function to sign in



def sign_in_func():

    cr.execute(f"select * from play")
    user_data = cr.fetchall()
    a = len(user_data)

    name = name_entry.get().strip().capitalize() # the name that user input
    password = pass_entry.get()
    for user in user_data:
        if user[0] != name and a == 1:
            messagebox.showinfo("Error", "user_name is not found")

        elif name == user[0]:

            if password == "":
                messagebox.showinfo("Error", f"{name} you can't enter empty password! " )
                break
            elif user[1] != password:
                messagebox.showinfo("Error", f"{name} you entered wrong password!")
                break

            else:
                # messagebox.showinfo("successful", f"{name} you signed in successfully!" )
                sign_in.destroy() # Close sign_in window

                root = Tk()  # إنشاء نافذة التطبيق الرئيسية
                root.geometry("1540x850")  # تعيي أبعاد النافذة
                root.title("Employee management")  # تعيين عنوان النافذة
                root.configure(bg="#003049")  # تعيين لون الخلفية
                root.iconbitmap(False, 'Icons\\teamwork.ico')  # تعيين ايقون للبرنامج
                root.resizable(False, False)  # (1300x515) تثبيت الحجم وعدم جعله يصغر او يكبر عن
                # =======================================================

                # ==================================================

                database = Database("employee.db")  # اعداد قاعدة بيانات

                # تعريف المتغيرات الخاصة بالحقول
                name = StringVar()
                age = StringVar()
                gender = StringVar()
                job = StringVar()
                phone = StringVar()

                # ===============Create Frame ============

                inputsFrame = Frame(root, background='#003049')  # تعيين مساحة معينه لاضافة المدخلات والازرار
                inputsFrame.place(x=1, y=1, width=360, height=615)  # تعيين ابعاد المساحة
                title = Label(inputsFrame, text='Employee SYS', font=('Calibri', 18, 'bold'), bg="#003049",
                              fg='white')  # تسمية المساحة
                title.place(x=100, y=1)  # ادراج الاسم في الفريم

                # ===============field Name=============

                lblName = Label(inputsFrame, text='Name', font=('Calibri', 16), bg="#003049", fg='white')
                lblName.place(x=15, y=50)  # ادراج الاسم الحقل في الفريم
                inputName = Entry(inputsFrame, textvariable=name, width=20, font=('Calibri', 16))
                inputName.place(x=75, y=50)  # وضع حقل الإدخال في الشبكة

                # ===============field Gender=============

                lblGender = Label(inputsFrame, text='Gender', font=('Calibri', 16), bg="#003049", fg='white')
                lblGender.place(x=10, y=100)
                boxGender = ttk.Combobox(inputsFrame, state="readonly", textvariable=gender, width=18,
                                         font=('Calibri', 16))
                boxGender['values'] = ("Male", "Female")
                boxGender.place(x=80, y=100)

                # ===============field Job=============

                lblJob = Label(inputsFrame, text='Job', font=('Calibri', 16), bg="#003049", fg='white')
                lblJob.place(x=15, y=150)
                inputJob = Entry(inputsFrame, textvariable=job, width=20, font=('Calibri', 16))
                inputJob.place(x=75, y=150)

                # ===============field Age=============

                lblAge = Label(inputsFrame, text='Age', font=('Calibri', 16), bg="#003049", fg='white')
                lblAge.place(x=15, y=200)
                inputAge = Entry(inputsFrame, textvariable=age, width=20, font=('Calibri', 16))
                inputAge.place(x=75, y=200)

                # ===============field Phone=============
                lblPhone = Label(inputsFrame, text='Phone', font=('Calibri', 16), bg="#003049", fg='white')
                lblPhone.place(x=15, y=250)
                inputPhone = Entry(inputsFrame, textvariable=phone, width=20, font=('Calibri', 16))
                inputPhone.place(x=75, y=250)

                # ============field Address===============
                lblAddress = Label(inputsFrame, text='Address:', font=('Calibri', 16), bg="#003049", fg='white')
                lblAddress.place(x=15, y=350)
                inputAddress = Text(inputsFrame, width=20, height=1.5, font=('Calibri', 16))
                inputAddress.place(x=75, y=380)
                # ===============================================================================

                # ===========Buttons(AddData/UpdataData/RemoveData/ClearData)===========
                # ==========Create Label Button=======
                btnFrame = Frame(inputsFrame, bg='#003049', border=1, relief=SOLID)
                btnFrame.place(x=20, y=450, width=300, height=160)

                # ===========Functions Buttons================
                # =========Functions Hide/Show TreeView=======
                # def Hide():
                #     root.geometry("1540x850")
                #
                # def Show():
                #     root.geometry("1540x850")

                # =============================================
                # =============================================
                # =============================================
                # =============================================
                # =============================================

                frame_hp = LabelFrame(root, bg='#003049')
                frame_hp.place(relx=0.000, rely=0.715, relwidth=0.85, relheight=0.3)

                # =============================================

                employee_hp = Label(frame_hp, text="Employees", font=('arial', 22, 'bold'), bg='#003049', fg='#a6a5a8')
                employee_hp.place(relx=0.2, rely=0.1, relwidth=0.2, relheight=0.3)

                # =============================================

                database = Database("employee.db")  # اعداد قاعدة بيانات
                num = len(database.fetch())  # انشاء متغير يحمل عدد الموظفين

                employee__hp = Label(frame_hp, font=('arial', 30, 'bold'), bg='#003049', fg='blue')
                employee__hp.configure(text=num)
                employee__hp.place(relx=0.25, rely=0.4, relwidth=0.1, relheight=0.25)

                # =============================================

                managers_hp = Label(frame_hp, text="Managers", font=('arial', 22, 'bold'), bg='#003049', fg='#a6a5a8')
                managers_hp.place(relx=0.6, rely=0.1, relwidth=0.2, relheight=0.3)

                # =============================================

                cr.execute(f"select * from play")
                user_data_ = cr.fetchall()
                a_hp = len(user_data_)

                managers_ = Label(frame_hp, font=('arial', 30, 'bold'), bg='#003049', fg='blue')
                managers_.configure(text=a_hp)
                managers_.place(relx=0.65, rely=0.4, relwidth=0.1, relheight=0.25)

                # =============================================

                f2 = LabelFrame(root, bg='#003049')
                f2.place(relx=0.8501, rely=0.0, relwidth=0.15, relheight=1)

                # =============================================

                n1label = Label(f2 , text='H\nU\nM\nA\nN' , fg='#a6a5a8' , font=('arial', 30, 'bold'), bg='#003049')
                n1label.place(relx=0.25, rely=.25, relwidth=0.15, relheight=.5)

                # =============================================

                n2label = Label(f2, text='R\nE\nS\nO\nU\nR\nC\nE\nS', fg='#a6a5a8', font=('arial', 30, 'bold'), bg='#003049')
                n2label.place(relx=0.55, rely=0.25, relwidth=0.15, relheight=.5)

                # =============================================
                # =============================================
                # =============================================
                # =============================================
                # =============================================

                # دالة لجلب البيانات من الجدول
                def getData(event):
                    selectedRow = show.focus()
                    info = show.item(selectedRow)
                    global row
                    row = info["values"]
                    name.set(row[1])
                    age.set(row[2])
                    job.set(row[3])
                    gender.set(row[4])
                    inputAddress.delete(1.0, END)
                    inputAddress.insert(END, row[5])
                    phone.set(row[6])

                # دالة لعرض جميع البيانات في الجدول
                def displayAll():
                    show.delete(*show.get_children())
                    for row in database.fetch():
                        show.insert("", END, values=row)

                # دالة لمسح البيانات من الحقول
                def clear():
                    name.set("")
                    age.set("")
                    job.set("")
                    phone.set("")
                    gender.set("")
                    inputAddress.delete(1.0, END)

                # دالة لحذف بيانات الموظف
                def delete():
                    database.remove(row[0])
                    clear()
                    displayAll()

                # دالة لتحديث بيانات الموظف
                def updata():
                    if inputName.get() == "" or inputAge.get() == "" or inputJob.get() == "" or inputAddress.get(1.0,
                                                                                                                 END) == "" or inputPhone.get() == "" or boxGender.get() == "":
                        messagebox.showerror("Error", "Please fill in the blank field")
                        return
                    database.update(row[0],
                                    inputName.get(),
                                    inputAge.get(),
                                    inputJob.get(),
                                    boxGender.get(),
                                    inputAddress.get(1.0, END),
                                    inputPhone.get(),
                                    )
                    messagebox.showinfo("Success", "Data updated")
                    clear()
                    displayAll()

                # دالة لإضافة موظف جديد
                def addEmployee():
                    if inputName.get() == "" or inputAge.get() == "" or inputJob.get() == "" or inputAddress.get(1.0,
                                                                                                                 END) == "" or inputPhone.get() == "" or boxGender.get() == "":
                        messagebox.showerror("Error", "Please fill in the blank field")
                        return
                    database.insert(
                        inputName.get(),
                        inputAge.get(),
                        inputJob.get(),
                        boxGender.get(),
                        inputAddress.get(1.0, END),
                        inputPhone.get(),
                    )
                    messagebox.showinfo("Success", "Added new employee!")
                    clear()
                    displayAll()

                def searchWindow():
                    # إنشاء نافذة جديدة
                    searchWin = Toplevel(root)
                    searchWin.geometry("800x400")
                    searchWin.title("Search Employee")
                    searchWin.configure(bg="#003049")

                    # تسمية حقل البحث
                    searchLabel = Label(searchWin, text="Enter Name or Phone to Search", font=('Calibri', 16),
                                        bg="#003049", fg='white')
                    searchLabel.pack(pady=20)

                    # حقل الإدخال للبحث
                    searchEntry = Entry(searchWin, font=('Calibri', 16))
                    searchEntry.pack(pady=10, padx=20, fill='x')

                    # دالة للبحث عند الضغط على زر البحث
                    def searchData():
                        searchText = searchEntry.get()
                        if searchText != "":
                            # البحث في قاعدة البيانات
                            results = database.search(searchText)  # إضافة دالة search في قاعدة البيانات
                            if results:
                                # مسح أي نتائج سابقة في جدول Treeview
                                for row in show.get_children():
                                    show.delete(row)

                                # عرض نتائج البحث في Treeview
                                for row in results:
                                    show.insert("", END, values=row)
                            else:
                                messagebox.showinfo("No Results", "No employees found.")
                        else:
                            messagebox.showerror("Error", "Please enter something to search.")

                    # زر البحث
                    searchButton = Button(searchWin, text="Search", font=('Calibri', 16), fg='white', bg='#386641',
                                          border=0, command=searchData)
                    searchButton.place(x=350, y=120)  # وضع زر البحث باستخدام place

                    # إنشاء Treeview لعرض النتائج
                    treeFrame = Frame(searchWin)
                    treeFrame.pack(pady=35, padx=10, fill='both', expand=True)

                    style = ttk.Style()
                    style.configure("mystyle.Treeview", font=('Calibri', 12), rowheight=30, background="#14213d",
                                    foreground="#e5e5e5")
                    style.configure("mystyle.Treeview.Heading", font=('Calibri', 12))

                    show = ttk.Treeview(treeFrame, columns=(1, 2, 3, 4, 5, 6, 7), style="mystyle.Treeview")
                    show.heading("1", text="ID")
                    show.column("1", width=40)
                    show.heading("2", text="Name")
                    show.column("2", width=180)
                    show.heading("3", text="Age")
                    show.column("3", width=40)
                    show.heading("4", text="Job")
                    show.column("4", width=160)
                    show.heading("5", text="Gender")
                    show.column("5", width=130)
                    show.heading("6", text="Address")
                    show.column("6", width=240)
                    show.heading("7", text="Phone")
                    show.column("7", width=160)
                    show['show'] = 'headings'
                    show.pack(fill='both', expand=True)

                # ===============================================================================

                # أزرار التحكم في البيانات
                btnAdd = Button(btnFrame, text='Add Data', width=12, height=1, font=('Calibri', 16), fg='white',
                                bg='#386641', border=0, command=addEmployee)
                btnAdd.place(x=2, y=3)
                btnDel = Button(btnFrame, text='Delete Data', width=12, height=1, font=('Calibri', 16), fg='white',
                                bg='#e63946', border=0, command=delete)
                btnDel.place(x=155, y=3)
                btnUpdata = Button(btnFrame, text='Updata Data', width=12, height=1, font=('Calibri', 16), fg='white',
                                   bg='#ffc300', border=0, command=updata)
                btnUpdata.place(x=2, y=50)
                btnClear = Button(btnFrame, text='Clear Data', width=12, height=1, font=('Calibri', 16), fg='white',
                                  bg='#0077b6', border=0, command=clear)
                btnClear.place(x=155, y=50)
                # أزرار التحكم في البيانات
                btnSearch = Button(btnFrame, text="Search", width=12, height=1, font=('Calibri', 16), fg='white',
                                   cursor='hand2', bg='#22577a', border=0, command=searchWindow)
                btnSearch.place(x=90, y=100)

                # ======================================================================

                # ==========Buttons(Hide TreeView/ Show TreeView)=======================
                # btnHide = Button(inputsFrame, text="HIDE", command=Hide, fg='white', cursor='hand2', bg='#e63946',
                #                  border=0)
                # btnHide.place(x=270, y=10)
                # btnShow = Button(inputsFrame, text="SHOW", command=Show, fg='white', cursor='hand2', bg='#386641',
                #                  border=0)
                # btnShow.place(x=30, y=10)

                # ==========Table Frame=============
                tableFrame = Frame(root, background='white')

                tableFrame.pack(fill='both', expand=True)
                tableFrame.place(x=370, y=1, width=940, height=605)  # قلل الارتفاع قليلاً

                style = ttk.Style()
                style.configure("mystyle.Treeview", font=('Calibri', 12), rowheight=50, background="#14213d",
                                foreground="#e5e5e5")
                style.configure("mystyle.Treeview.Heading", font=('Calibri', 12))

                show = ttk.Treeview(tableFrame, columns=(1, 2, 3, 4, 5, 6, 7), style="mystyle.Treeview")
                show.heading("1", text="ID")
                show.column("1", width=40)
                show.heading("2", text="Name")
                show.column("2", width=180)
                show.heading("3", text="Age")
                show.column("3", width=40)
                show.heading("4", text="Job")
                show.column("4", width=160)
                show.heading("5", text="Gender")
                show.column("5", width=130)
                show.heading("6", text="Address")
                show.column("6", width=230)
                show.heading("7", text="Phone")
                show.column("7", width=160)

                show['show'] = 'headings'
                show.place(x=0.5, y=0.5, height=620)
                show.bind("<ButtonRelease-1>", getData)

                # عرض جميع البيانات عند بدء التشغيل
                displayAll()

                # بدء حلقة تشغيل البرنامج
                root.mainloop()

                root.mainloop()  # بدء الحلقة الرئيسية لتشغيل التطبيق



# ________________________________________________________________________________________________


#Function to call sign_up window
def sign_up_func():


    # Function to sign-up
    def sign_up_func_():
        cr.execute(f"select * from play")
        user_data_ = cr.fetchall()
        a = len(user_data_)

        name = new_name_entry.get().strip().capitalize()
        pass_sign_up = new_pass_entry.get()
        confirm_pass_sign_up = confirm_new_pass_entry.get()

        for user in user_data_:
            if name == "":
                messagebox.showerror("Error", f"you can't enter an empty name!")
                break

            elif pass_sign_up == "" or confirm_pass_sign_up == "":
                messagebox.showerror("Error", f"you can't enter an empty password!")
                break

            elif name != user[0] and a == 1  :
                if pass_sign_up == confirm_pass_sign_up:
                    cr.execute(f"insert into play(name,password) values ('{name}' , '{pass_sign_up}')")
                    db.commit()
                    messagebox.showinfo("successful" , f"{name} you signed up successfully!")
                    sign_up.destroy()
                    sign_in.deiconify()
                    break

                else:
                    messagebox.showerror("Error" , f"The two passwords don't match!")
                    break

            elif name == user[0]:
                messagebox.showerror("Error", f"this name already has a password!")
                break

            a -= 1


    sign_in.withdraw() #Hide sign-in window.

    #create sign-up window.
    sign_up= tkinter.Toplevel()

    sign_up.title('الموارد البشرية')  # title of sign up window.
    sign_up.geometry('1540x850')  # geometry of sign up window.
    sign_up.resizable(False, False)  # make user can't change the geometry.
    sign_up.iconbitmap(False, 'Icons\\teamwork.ico')  # use icon for window.
    sign_up.configure(background='#d0e4f5') #change the color of background.

    # creat a variable contains image in sign_up window.
    back_button_img = PhotoImage(file="image\\4091 (1).png")    # # insert the image into the window --> 650x650
    image_lab = Label(sign_up, image=back_button_img)
    image_lab.place(x=880, y=180) # --> the position of image in window.

    #title

    title_sign_up = Label(sign_up, text='إدارة الموارد البشرية', font=('Arial', 40, 'bold'), fg='#3437eb', bg='#d0e4f5')
    title_sign_up.place(x=600, y=50)

    # تسجيل مستخدم جديد
    label_su = Label(sign_up, text='تسجيل مستخدم جديد (مدير)', bg="#d0e4f5", font=('Arial', 40, 'bold'), fg='#3437eb', padx=10)
    label_su.place(x=230, y=230)

    # new-user-name
    new_name_label = Label(sign_up, text='Username', font=('Arial', 30, 'bold'), fg='#707073', bg='#d0e4f5')
    new_name_label.place(x=200, y=345)

    new_name_entry = ttk.Entry(sign_up, font=('Arial', 25))
    new_name_entry.place(x=400, y=350)

    # password
    new_pass_label = Label(sign_up, text='Password', font=('Arial', 30, 'bold'), fg='#707073', bg='#d0e4f5')
    new_pass_label.place(x=200, y=445)

    new_pass_entry = ttk.Entry(sign_up, font=('Arial', 25), show='*')
    new_pass_entry.place(x=400, y=450)

    def new_show_hide():
        if new_show_hide_button['text'] == 'Show':
            new_pass_entry.configure(show='')
            new_show_hide_button.configure(text='Hide', font=('Arial', 16, 'bold'))
        else:
            new_pass_entry.configure(show='*')
            new_show_hide_button.configure(text='Show', font=('Arial', 15, 'bold'))

    new_show_hide_button = Button(sign_up, text='Show', font=('Arial', 15, 'bold'), fg="#3437eb", command=new_show_hide)
    new_show_hide_button.place(x=770, y=450)



    # confirm password
    confirm_new_pass_label = Label(sign_up, text='Confirm Password', font=('Arial', 30, 'bold'), fg='#707073', bg='#d0e4f5')
    confirm_new_pass_label.place(x=37, y=545)

    confirm_new_pass_entry = ttk.Entry(sign_up, font=('Arial', 25), show='*')
    confirm_new_pass_entry.place(x=400, y=550)

    def confirm_new_show_hide():
        if confirm_new_show_hide_button['text'] == 'Show':
            confirm_new_pass_entry.configure(show='')
            confirm_new_show_hide_button.configure(text='Hide', font=('Arial', 16, 'bold'))
        else:
            confirm_new_pass_entry.configure(show='*')
            confirm_new_show_hide_button.configure(text='Show', font=('Arial', 15, 'bold'))

    confirm_new_show_hide_button = Button(sign_up, text='Show', font=('Arial', 15, 'bold'), fg="#3437eb", command=confirm_new_show_hide)
    confirm_new_show_hide_button.place(x=770, y=550)

    #change ttk style.
    s1 = ttk.Style()
    s1.configure('.', font=('Helvetica', 25), fg='#707073')

    # Confirm button
    confirm_ = ttk.Button(sign_up, text='Confirm', command=sign_up_func_)
    confirm_.place(x=575, y=650)

    # function to close sign_up window and show sign_in window again
    def close_and_show_window():
        sign_up.destroy()
        sign_in.deiconify()

    # Cancel button return to sign-in window
    clic_sign_up_ = ttk.Button(sign_up, text='Cancel', command= close_and_show_window)
    clic_sign_up_.place(x=350, y=650)



    sign_up.mainloop()


sign_in.title('الموارد البشرية') #title of sign in window.
sign_in.geometry('1540x850') #geometry of sign in window.
sign_in.resizable(False, False) #make user can't change the geometry.
sign_in.iconbitmap(False, 'Icons\\teamwork.ico')  # use icon for window.
sign_in.configure(background='#d0e4f5')

#creat a variable contains image in sign_in window.
image = PhotoImage(file='image\\4091 (1).png')
img = Label(sign_in, image=image)
img.place(x=880, y=180)
#title
title = Label(sign_in , text='إدارة الموارد البشرية' , font=('Arial', 40,'bold'), fg = '#3437eb' , bg = '#d0e4f5')
title.place(x=600,y=50)

#تسجيل الدخول
label = Label(sign_in , text='تسجيل الدخول (مدير)' ,bg = "#d0e4f5", font=('Arial', 40,'bold'),fg = '#3437eb' , padx = 10)
label.place(x=325,y=230)

#user-name
name_label = Label(sign_in , text='Username' , font=('Arial', 30,'bold'),fg = '#707073' , bg = '#d0e4f5')
name_label.place(x=200,y=345)

name_entry = ttk.Entry(sign_in  ,font=('Arial', 25) )
name_entry.place(x=400,y=350)

#password
pass_label = Label(sign_in , text='Password' , font=('Arial', 30,'bold') , fg = '#707073' , bg = '#d0e4f5')
pass_label.place(x=200,y=445)

pass_entry = ttk.Entry(sign_in  ,font=('Arial', 25), show= '*')
pass_entry.place(x=400,y=450)

def show_hide():
    if show_hide_button['text'] == 'Show':
        pass_entry.configure(show='')
        show_hide_button.configure(text='Hide' , font=('Arial', 16,'bold'))
    else:
        pass_entry.configure(show='*')
        show_hide_button.configure(text='Show', font=('Arial' , 15 , 'bold'))

show_hide_button = Button(sign_in , text = 'Show', font=('Arial' , 15 , 'bold') , fg = "#3437eb"  , command=show_hide )
show_hide_button.place(x=770,y=450)

#sign_in button

# Make changes on ttk-Button.
s = ttk.Style()
s.configure('.', font=('Helvetica', 25  ), fg = '#707073')

clic_sign_in = ttk.Button(sign_in , text = 'Confirm' , command = sign_in_func)
clic_sign_in.place(x=575,y=550)

#sign_up button
clic_sign_up = ttk.Button(sign_in , text = 'Sign-up', command = sign_up_func )
clic_sign_up.place(x=350,y=550)
db.commit()

sign_in.mainloop()

